package tests;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import appModule.AddToCartAction;
import appModule.ChangeCountryAction;
import core.BasicSeleniumTest;
import pageObjects.CartPage;

public class TestAddToCart extends BasicSeleniumTest{

// Here we are calling the Data Provider object with its Name
@Test(dataProvider = "Authentication")
public void testAddToCart(String sNovel, String sAuthor) throws Exception {

// Change country
ChangeCountryAction.Execute(driver);
	
// Add to cart
AddToCartAction.Execute(driver, sNovel, sAuthor);

// Validate the title of the book
Assert.assertEquals(driver.getTitle(), CartPage.ExpectedTitle);
Reporter.log("Step 11 - Title validation - PASSED");

}

}