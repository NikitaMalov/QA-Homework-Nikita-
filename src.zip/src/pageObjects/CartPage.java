package pageObjects;

public class CartPage {
	
	public static String ExpectedTitle = "Treasure Island by Robert Louis Stevenson";
	
    
}
