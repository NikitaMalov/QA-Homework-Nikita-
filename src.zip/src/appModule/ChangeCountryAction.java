package appModule;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

import pageObjects.HomePage;

public class ChangeCountryAction {
	
	public static void Execute(WebDriver driver) throws Exception{
		
		HomePage.LnkDeliverTo(driver).click();
		Reporter.log("Step 1 - Click Deliver to - PASSED");
		
		HomePage.LnkCountryDropdown(driver).click();
		Reporter.log("Step 2 - Click Country dropdown box - PASSED");
	
		HomePage.ClickCountry(driver).click();
		Reporter.log("Step 3 - Select Country - PASSED");
				
		HomePage.btnDone(driver).click();
		Reporter.log("Step 4 - Click Done - PASSED");

	}
}
//DONE