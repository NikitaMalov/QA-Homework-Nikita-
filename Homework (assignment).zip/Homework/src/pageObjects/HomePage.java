package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utility.LocatorUtils;

public class HomePage {
	
	public static String LnkDeliverTo = "#nav-global-location-popover-link";
	public static String LnkCountryDropdown = "#GLUXCountryListDropdown";
	public static String ClickCountry = "//*[@id=\"GLUXCountryList_183\"]";
	public static String btnDone = "#a-autoid-19";
	public static String txtbxSearch = "#twotabsearchtextbox";
	public static String btnSearch = "#nav-search-submit-button";
    
    
    
  
     // Link Deliver to method
    public static WebElement LnkDeliverTo(WebDriver driver){
 	   return LocatorUtils.findElement(driver, "css", LnkDeliverTo); 
    }
 	   
 	// Link Country Dropdown Box method
 	    public static WebElement LnkCountryDropdown(WebDriver driver){
 	 	   return LocatorUtils.findElement(driver, "css", LnkCountryDropdown); 
 	    }
 	    
 	// Choose France method
 	    public static WebElement ClickCountry(WebDriver driver){
 	 	   return LocatorUtils.findElement(driver, "xpath", ClickCountry); 
 	    }
    
 	// Button Done method
 	    public static WebElement btnDone(WebDriver driver){
 	 	   return LocatorUtils.findElement(driver, "css", btnDone); 
 	    }
 	    
    // Search field method
    public static WebElement txtbxSearch(WebDriver driver){
 	   return LocatorUtils.findElement(driver, "css", txtbxSearch);  	   
    }
 	   
 	// Search button method
    public static WebElement btnSearch(WebDriver driver){
 	 	 return LocatorUtils.findElement(driver, "css", btnSearch);  
 	}
    
 	    
 	}
//DONE

