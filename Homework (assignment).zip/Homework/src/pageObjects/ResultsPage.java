package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utility.LocatorUtils;

public class ResultsPage {

public static String linkSelectBook = "#search > div.s-desktop-width-max.s-desktop-content.s-wide-grid-style-t1.s-opposite-dir.s-wide-grid-style.sg-row > div.sg-col-20-of-24.s-matching-dir.sg-col-16-of-20.sg-col.sg-col-8-of-12.sg-col-12-of-16 > div > span.rush-component.s-latency-cf-section > div.s-main-slot.s-result-list.s-search-results.sg-row > div:nth-child(5) > div > div > div > div > div > div.sg-col.sg-col-4-of-12.sg-col-8-of-16.sg-col-12-of-20.s-list-col-right > div > div > div.a-section.a-spacing-none.puis-padding-right-small.s-title-instructions-style > h2 > a > span";
public static String btnAdd = "#add-to-cart-button";
//need to be CHECKED!!!
public static String btnCart = "#nav-cart-count-container";

//Select the book method
public static WebElement linkSelectBook(WebDriver driver){
 	 return LocatorUtils.findElement(driver, "css", linkSelectBook);  
}

// Add to cart button method
public static WebElement btnAdd(WebDriver driver){
   return LocatorUtils.findElement(driver, "css", btnAdd);
}

// Cart button method
public static WebElement btnCart(WebDriver driver){
   return LocatorUtils.findElement(driver, "css", btnCart);
}

}