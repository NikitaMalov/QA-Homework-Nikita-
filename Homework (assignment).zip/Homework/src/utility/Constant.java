package utility;

public class Constant {
	
	public static final String URL = "https://www.amazon.com/";

	public static final String Path_TestData = "D:\\БАЗА\\САМОРАЗВИТИЕ\\QA\\Part 2 Automation Testing\\Test environment\\AutomationWorkSpace\\Amazon\\src\\testData/";
	
	public static final String File_TestData = "TestData.xlsx";
	
    public static final String Sheet_Name = "Sheet1";
	
	public static final int SHORT_DELAY = 5;
	
	public static final int LONG_DELAY = 10;
}
