package appModule;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

import pageObjects.HomePage;
import pageObjects.ResultsPage;

public class AddToCartAction {
	
	public static void Execute(WebDriver driver, String sNovel, String sAuthor) throws Exception{
		
		//need to be CHECKED!!!
		HomePage.txtbxSearch(driver).sendKeys(sNovel);
		Reporter.log("Step 5 - Enter novel - PASSED");
		HomePage.txtbxSearch(driver).sendKeys(sAuthor);
		Reporter.log("Step 6 - Enter author - PASSED");
		
		HomePage.btnSearch(driver).click();
		Reporter.log("Step 7 - Click Search Button - PASSED");
		
		ResultsPage.linkSelectBook(driver).click();
		Reporter.log("Step 8 - Select the book - PASSED");
		
		ResultsPage.btnAdd(driver).click();
		Reporter.log("Step 9 - Click Add to cart button - PASSED");
		
		ResultsPage.btnCart(driver).click();
		Reporter.log("Step 10 - Click Cart button - PASSED");

			}
}
